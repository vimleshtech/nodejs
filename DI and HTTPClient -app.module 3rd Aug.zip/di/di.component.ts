import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';


@Component({
  selector: 'app-di',
  templateUrl: './di.component.html',
  styleUrls: ['./di.component.css']
})
export class DiComponent implements OnInit {

  data
  constructor(private obj:UserService) {
    this.data = []
    

  obj.getData().subscribe((res)=>{
    this.data.push(res)
    console.log(res);
  });

    //console.log(this.data);


   }

  ngOnInit() {
  }

}
