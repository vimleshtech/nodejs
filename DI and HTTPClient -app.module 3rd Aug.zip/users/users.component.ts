import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  userid:number
  username:string 
  email:string 
  dob:string

  users=[]


  constructor() { }

  ngOnInit() {
  }

  set_userid(event){

  this.userid =  event.target.value;

  }

set_username(event){

  this.username =  event.target.value;
  console.log(this.username);
  }
  
  set_email(event){
    this.email =  event.target.value;

      }

      set_dob(event){
        this.dob =  event.target.value;
          }
          
      
          frm_submit(){

            this.users.push({uid:this.userid,uname:this.username,email:this.email,dob:this.dob});
            console.log(this.users);


          }

          delete(i){
              console.log(i);
              this.users.splice(i,1); //i start index, and 1 is no of elements 
          }

}
